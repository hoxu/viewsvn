<?php
header('Content-type: text/xml');

echo "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n";
echo "<rss version=\"2.0\">\n";
echo "<channel>\n";

$uri = 'http://'. $_SERVER['HTTP_HOST'] . $_SERVER['SCRIPT_NAME'];

/* Required channel elements */
echo "<title>$page[project] repository: $page[path]</title>\n";
echo "<link>$uri</link>\n";
echo "<description>Subversion repository commits for project $page[project]</description>\n";

/* Optional elements */
echo "<generator>ViewSVN</generator>\n";
if (isset($config['rss_ttl'])) {
	echo "<ttl>$config[rss_ttl]</ttl>\n";
}

foreach ($page['items'] as $entry) {
	echo "<item>\n";

	// title: revision and snippet of log entry
	echo "\t<title>r"
	.sprintf("%04d", $entry['rev'])
	.": ".
	$entry['msg_snippet']
	."</title>\n";
	echo "\t<author>$entry[author]</author>\n";
	echo "\t<link>$uri?do=browse&amp;project=$page[project]&amp;path=$page[path]&amp;rev=$entry[rev]</link>\n";

	// unique identifier for the item
	echo "\t<guid isPermaLink=\"false\">$page[project]-r$entry[rev]</guid>\n";

	// the item body
	echo "\t<description>"
	. $entry['date'] ." ". $entry['time']
	. "&lt;br/>\n"
	. $entry['msg']
	. "&lt;br/>Changed paths:&lt;br/>\n"
	. "&lt;ul>\n";
	foreach ($entry['paths'] as $changed_path) {
		echo "&lt;li>$changed_path[action]: $changed_path[path]&lt;/li>\n";
	}
	echo "&lt;/ul>\n"
	. "\t</description>\n";

	echo "</item>\n";
}

echo "</channel>\n";
echo "</rss>\n";
?>

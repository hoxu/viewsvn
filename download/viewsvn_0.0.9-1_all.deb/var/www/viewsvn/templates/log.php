<?php
require('header.php');
require('path.php');

echo "<h1>Changes for $page[path] before $page[rev]</h1>\n";
?>

<div class="log">

<?php
$isdir = (substr($page['path'], -1, 1) == '/');
$selftype = ($isdir ? 'path' : 'file');

$num = 0;
foreach ($page['entries'] as $i) {
	$num++;
	unset($prevrev);

	echo "<div class=\"entry\">\n";

	echo "<div class=\"info\">";
	echo "<a name=\"r$i[rev]\"></a>\n";

	echo "<span class=\"rev\"><a href=\"?do=log&amp;project=$page[project]&amp;path=$page[path]&amp;rev=$i[rev]#r$i[rev]\" title=\"Link to this log entry\">$i[rev]</a></span> | \n";

	echo "<span class=\"author\">$i[author]</span> |\n";
	echo "<span class=\"date\">$i[date] $i[time]</span>\n";

	$do = ($isdir ? 'browse' : 'view');
	echo "| <span class=\"browse\"><a href=\"?do=$do&amp;project=$page[project]&amp;path=$page[path]&amp;rev=$i[rev]\" title=\"$do this $selftype in revision $i[rev]\">". ucfirst($do) ."</a></span>\n";

	if ($num < count($page['entries']) && $config['enable_diff']) {
		$prevrev = $page['entries'][$num]['rev'];
		echo "| <span class=\"diff\"><a href=\"?do=diff&amp;project=$page[project]&amp;path=$page[path]&amp;rev=$i[rev]&amp;oldrev=$prevrev\">View changes</a></span>\n";
	}
	echo "</div>\n";

	echo "<div class=\"paths\">\n<ul>\n";
	// TODO how to figure out if the changed node is a file or dir?
		// TODO link action: D => view previous revision (how?)
		// TODO link path to browse/view?
	foreach ($i['paths'] as $p) {
		// Remove everything after last slash to get path the changed node is in
		$basedir = preg_replace('#[^/]+$#', '', $p['path']);

		echo "<li>[";
		// Link M to diff
		if ($p['action'] == 'M' && isset($prevrev)) {
			echo "<a href=\"?do=diff&amp;project=$page[project]&amp;path=$p[path]&amp;rev=$i[rev]&amp;oldrev=$prevrev\" title=\"Diff with previous revision\">M</a>";
		}
		// Link A to view rev
		elseif ($p['action'] == 'A') {
			echo "<a href=\"?do=view&amp;project=$page[project]&amp;path=$p[path]&amp;rev=$i[rev]\">A</a>";
		}
		else {
			echo "$p[action]";
		}
		echo "] <a href=\"?do=browse&amp;project=$page[project]&amp;path=$basedir&amp;rev=$i[rev]\">$p[path]</a>";

		if (isset($p['copyfrom-path'])) {
			$frompath = $p['copyfrom-path'];
			$fromrev = $p['copyfrom-rev'];
			echo " (from <a href=\"?do=log&amp;project=$page[project]&amp;path=$frompath&amp;rev=$fromrev\">". $frompath ."@". $fromrev ."</a>)";
		}

		echo "</li>\n";
	}

	echo "</ul>\n</div>\n";
	
	echo "<div class=\"msg\"><pre>$i[msg]</pre></div>\n";

	$lastrev = $i['rev'];
	echo "</div>\n\n";
}
echo "</div>\n";
echo "<div class=\"nav\">\n";
if ($page['rev'] != 'HEAD') {
	echo "<a href=\"?do=log&amp;project=$page[project]&amp;path=$page[path]\">Newest log entries</a>";
}
if (isset($lastrev) && $lastrev != 1 && ($num == $config['log_limit'])) {
	echo "<a href=\"?do=log&amp;project=$page[project]&amp;path=$page[path]&amp;rev=$lastrev\">Older log entries</a>";
}
echo "</div>\n";
?>

<?php
require('footer.php');
?>

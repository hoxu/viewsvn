<?php
require('header.php');
require('path.php');

echo "<h1>Differences for $page[path] between r$page[oldrev] and r$page[rev]</h1>\n";

echo "<div class=\"file\"><pre>";
echo $page['content'];
echo "</pre></div>";

echo "<div class=\"nav\">";
echo "<a href=\"?do=diff&amp;project=$page[project]&amp;path=$page[path]&amp;rev=$page[rev]&amp;oldrev=$page[oldrev]&amp;raw=1\">Download raw diff</a>";
echo "</div>\n";

require('footer.php');
?>

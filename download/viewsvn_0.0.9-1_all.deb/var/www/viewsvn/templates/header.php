<?php
echo "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
	<title><?php echo $page['title']; ?></title>
	<link rel="stylesheet" href="<?php echo $config['style']; ?>" type="text/css" />
<?php
if ($config['enable_rss'] && isset($project) && isset($path)) {
	echo "\t<link rel=\"alternate\" title=\"ViewSVN RSS\" href=\"?do=rss&amp;project=$page[project]&amp;path=$page[path]\" type=\"application/rss+xml\" />\n";
}
?>
<?php if (isset($page['description'])) { ?>
	<meta name="description" content="<?php echo $page['description']; ?>" />
<?php } if (isset($page['keywords'])) { ?>
	<meta name="keywords" content="viewsvn, repository, <?php echo $page['keywords']; ?>" />
<?php } ?>
</head>
<body>


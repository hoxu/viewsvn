<?php

$config['svnroot'] = 'svn://localhost';
$config['startpath'] = '/trunk/';

$config['projects'] = array(
	// svn://localhost/viewsvn
	'viewsvn' => array(
		'description' => 'Viewing Subversion (SVN) repositories via HTTP',
		'startpath' => '/tags/',
		'svnusername' => 'viewsvn',
		'svnpassword' => 'readonly',
	),
	// http://svn.someserver.org/fubar
	// If this is not in local network, it's sloooooow
	'fubar' => array(
		'description' => 'External fubar project',
		'root' => 'http://svn.someserver.org/fubar',
		'startpath' => '/trunk/',
	),
);

$config['ad'] = false;
$config['author_link'] = 'http://sourceforge.net/users/%s/';
$config['enable_geshi'] = true;
$config['rewrite'] = 2;

<?php
echo "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
	<title><?php echo $page['title']; ?></title>
	<link rel="stylesheet" href="<?php echo $page['base_href'] .'/'. $config['style']; ?>" type="text/css" />
	<link rel="shortcut icon" href="<?php echo $page['base_href']; ?>/images/favicon1.png" />
<?php
if ($config['enable_rss'] && isset($project) && isset($path)) {
	echo "\t<link rel=\"alternate\" title=\"ViewSVN RSS\" href=\"". makelink(array('do' => 'rss', 'project' => $page['project'], 'path' => $page['path'])) ."\" type=\"application/rss+xml\" />\n";
}
?>
<?php if (isset($page['description'])) { ?>
	<meta name="description" content="<?php echo $page['description']; ?>" />
<?php } if (isset($page['keywords'])) { ?>
	<meta name="keywords" content="viewsvn, repository, <?php echo $page['keywords']; ?>" />
<?php } ?>
	<script src="<?php echo $page['base_href']; ?>/scripts/sorttable.js"></script>
</head>
<body>

<div id="page_<?php echo $template; ?>">

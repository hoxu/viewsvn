<?php
require('path.php');

echo "<h1>". htmlentities($page['path']) . " (r$rev)";
if ($rev !== 'HEAD') {
	echo " (<a href=\"". makelink(array('do' => 'view', 'project' => $page['project'], 'path' => $page['path'])) ."\">head</a>)";
}
echo "</h1>\n";

echo "<div class=\"file\"><pre>";
echo $page['filecontent'];
echo "</pre></div>";

echo "<div class=\"nav\">";
if ($config['enable_annotate']) {
	echo "<a href=\"". makelink(array('do' => 'view', 'project' => $page['project'], 'path' => $page['path'], 'rev' => $page['rev'], 'annotate' => '1')) ."\">Annotate</a>\n";
}
if ($config['enable_log']) {
	echo "<a href=\"". makelink(array('do' => 'log', 'project' => $page['project'], 'path' => $page['path'], 'rev' => $page['rev'])) ."\">View log</a>\n";
}
echo "<a href=\"". makelink(array('do' => 'view', 'project' => $page['project'], 'path' => $page['path'], 'rev' => $page['rev'], 'raw' => '1')) ."\">Raw source</a>\n";
echo "</div>";

?>

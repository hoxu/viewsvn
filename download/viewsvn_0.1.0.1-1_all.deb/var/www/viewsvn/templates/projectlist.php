<h1>List of projects available for viewing</h1>

<div id="projectlist">
<ul>
<?php
foreach ($page['projects'] as $proj) {
	echo "\t<li><a href=\"". makelink(array('do' => 'browse', 'project' => $proj['name'], 'path' => $proj['path'])) ."\">$proj[name]";
	if (isset($proj['description'])) {
		echo " &sim; $proj[description]";
	}
	echo "</a></li>\n";
}
?>
</ul>
</div>

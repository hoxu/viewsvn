<div class="path">
<?php
echo "[ <a href=\"". makelink(array('do' => 'browse', 'project' => $page['project'], 'path' => '/')) ."\">$page[project]</a> ]";
$now = '/';
foreach ($page['pathnodes'] as $p) {
	$now .= $p .'/';
	echo " / <a href=\"". makelink(array('do' => 'browse', 'project' => $page['project'], 'path' => $now)). "\">$p</a>";
}
echo ' /';
?>
</div>

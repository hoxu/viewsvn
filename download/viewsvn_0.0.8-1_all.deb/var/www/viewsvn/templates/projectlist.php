<?php
require('header.php');
?>

<h1>List of projects available for viewing</h1>

<div id="projectlist">
<ul>
<?php
foreach ($page['projects'] as $proj) {
	echo "\t<li><a href=\"?do=browse&amp;project=$proj[name]&amp;path=$proj[path]\">$proj[name]";
	if (isset($proj['description'])) {
		echo " &sim; $proj[description]";
	}
	echo "</a></li>\n";
}
?>
</ul>
</div>

<?php
require('footer.php');
?>

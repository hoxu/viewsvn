<?php
require('header.php');
require('path.php');

?>
<pre>
<table class="list">
<tr>
	<th>File</th>
	<th>Rev.</th>
	<th>Changed</th>
	<th>Size</th>
</tr>
<?php
foreach ($page['nodes'] as $n) {
	echo "<tr>\n";
	echo "\t<td>";
	$do = ($n['isdir'] ? 'browse' : 'view');
	$baseuri = "?do=$do&amp;project=$page[project]&amp;path=$page[path]$n[filename]";
	echo "<a href=\"$baseuri&amp;$rev=$page[rev]\">";
	echo "$n[filename]</a>\n";
	echo "</td>\n";
	echo "\t<td><a href=\"$baseuri&amp;$rev=$n[rev]\">$n[rev]</a></td>\n";
	echo "\t<td>". strftime($config['browse_changed_format'], $n['age']) ."</td>\n";
	echo "\t<td class=\"size\">$n[size]</td>\n";
	echo "</tr>\n";
}
echo "</table>\n";
echo "</pre>\n";

require('footer.php');
?>

<div class="path">
<?php
echo "[ <a href=\"?do=browse&amp;project=$page[project]&amp;path=/\">$page[project]</a> ]";
$now = '/';
foreach ($page['pathnodes'] as $p) {
	$now .= $p .'/';
	echo " / <a href=\"?do=browse&amp;project=$page[project]&amp;path=$now\">$p</a>";
}
echo ' /';
?>
</div>

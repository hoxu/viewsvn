<?php
require('header.php');
?>

<div class="project"><a href=".">List of projects</a></div>

<?php
require('path.php');
?>

<div class="revchange" style="text-align: center">
<form method="get">
<input type="hidden" name="do" value="browse" />
<input type="hidden" name="project" value="<?php echo $page['project']; ?>" />
<input type="hidden" name="path" value="<?php echo $page['path']; ?>" />
<input type="text" name="rev" value="<?php echo $page['rev']; ?>" style="width: 6em" />
<input type="submit" value="Go" />
</form>
<?php
if ($page['rev'] != 'HEAD') {
	echo "(<a href=\"?do=browse&amp;project=$page[project]&amp;path=$page[path]\">head</a>)";
}
?>
</div>

<div class="files">

<table>
<tr class="header">
	<td>File</td>
	<td>Rev.</td>
	<td>Changed</td>
	<td>Author</td>
	<td>Last log entry</td>
</tr>
<?php
foreach ($page['nodes'] as $n) {
	echo "<tr class=\"";
	if ($n['isdir'] === true) {
		echo 'dir';
	} else {
		echo 'file';
	}
	if ($n['rev'] == $page['rev']) {
		echo ' currev';
	}
	echo "\">\n";
	
	$do = ($n['isdir'] ? 'browse' : 'view');
	echo "\t<td class=\"name\"><a href=\"?do=$do&amp;project=$page[project]&amp;path=$page[path]$n[filename]\">$n[filename]</a></td>\n";

	echo "\t<td class=\"rev\"><a href=\"?do=browse&amp;project=$page[project]&amp;path=$page[path]&amp;rev=$n[rev]\">$n[rev]</a></td>\n";

	echo "\t<td class=\"age\">". strftime($config['browse_changed_format'], $n['age']) ."</td>\n";
	echo "\t<td class=\"author\">$n[author]</td>\n";
	echo "\t<td class=\"log\"><a href=\"?do=log&amp;project=$page[project]&amp;path=$page[path]$n[filename]#r$n[rev]\" title=\"View full log entry\">&raquo;</a> $n[log]</td>\n";
	echo "</tr>\n";
}
?>
</table>

</div>

<div class="nav">
<?php
if ($config['enable_log']) {
	echo "<span class=\"log\"><a href=\"?do=log&amp;project=$page[project]&amp;path=$page[path]&amp;rev=$page[rev]\">View log</a></span>";
}
if ($config['enable_download']) {
	echo "<span class=\"download\"><a href=\"?do=download&amp;project=$page[project]&amp;path=$page[path]&amp;rev=$page[rev]\" rel=\"nofollow\">Download .tar.bz2</a></span>";
}
if ($config['enable_list']) {
	echo "<span class=\"list\"><a href=\"?do=list&amp;project=$page[project]&amp;path=$page[path]&amp;rev=$page[rev]\">List</a></span>";
}
?>
</div>

<?php
if (isset($page['proplist'])) {
	echo "<div class=\"file\"><pre>$page[proplist]</pre></div>";
}

require('footer.php');
?>

<?php
require('header.php');
require('path.php');

echo "<h1>$page[path] (r$rev)</h1>\n";

echo "<div class=\"file\"><pre>";
echo $page['filecontent'];
echo "</pre></div>";

echo "<div class=\"nav\">";
if ($config['enable_annotate']) {
	echo "<a href=\"?do=view&amp;project=$page[project]&amp;path=$page[path]&amp;rev=$page[rev]&amp;annotate=1\">Annotate</a>\n";
}
if ($config['enable_log']) {
	echo "<a href=\"?do=log&amp;project=$page[project]&amp;path=$page[path]&amp;rev=$page[rev]\">View log</a>\n";
}
echo "<a href=\"?do=view&amp;project=$page[project]&amp;path=$page[path]&amp;rev=$page[rev]&amp;raw=1\">Raw source</a>\n";
echo "</div>";

require('footer.php');
?>

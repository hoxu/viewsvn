<?php
/** @file index.php
 * The main controller gadget. Reads config, processes user input, acts
 * accordingly and finally passes required data to templates.
 */
require('include/config.php');
require('include/libsvn.php');
if ($config['debug']) { error_reporting(E_ALL); }

// ------------------------------------------------------------
// Process parameters
// ------------------------------------------------------------

if (isset($_REQUEST['do'])) { $do = $_REQUEST['do']; } else { $do = 'index'; }
if (isset($_REQUEST['project'])) { $project = $_REQUEST['project']; }
if (isset($_REQUEST['path'])) { $path = $_REQUEST['path']; }
if (isset($_REQUEST['rev'])) { $rev = $_REQUEST['rev']; }
if (isset($_REQUEST['oldrev'])) { $oldrev = $_REQUEST['oldrev']; }

// TODO validate path (no ..'s = escaping out of svnroot)? SVN does this already.
if (isset($project) && !isset($config['projects'][$project])) { unset($project); }
if (!isset($path)) { $path = '/'; }
if (isset($rev) && $rev != 'HEAD' && !is_numeric($rev)) { unset($rev); }
if (isset($oldrev) && $oldrev != 'HEAD' && !is_numeric($oldrev)) { unset($oldrev); }
if (!isset($rev)) { $rev = 'HEAD'; }

// ------------------------------------------------------------
// Init SVN
// ------------------------------------------------------------

$svn = new SVN();
if (isset($config['svnusername']) && isset($config['svnpassword'])) {
	$svn->setAuthentication($config['svnusername'], $config['svnpassword']);
}
if (isset($config['cachedir'])) { $svn->setCacheDir($config['cachedir']); }

if (isset($config['svncommand'])) { $svn->setCommand($config['svncommand']); }
if (isset($project)) {
	$p = $config['projects'][$project];
	
	if (isset($p['root'])) {
		$svn->setRoot($p['root']);
	}
	elseif (isset($config['svnroot'])) {
		$svn->setRoot($config['svnroot'] .'/'. $project);
	}
	else {
		die("SVN root not configured for '$project'");
	}

	if (isset($p['username']) && isset($p['password'])) {
		$svn->setAuthentication($p['username'], $p['password']);
	}
}
if (isset($path)) {
	$svn->setPath($path);
}

// ------------------------------------------------------------
// Handle actions
// ------------------------------------------------------------

// Information available for all templates
if (isset($project)) { $page['project'] = $project; }
$page['path'] = $path;
$page['rev'] = $rev;
$page['pathnodes'] = split('/', $path);
if (isset($project) && isset($path)) { $page['title'] = "$project:$path - ViewSVN"; }
array_shift($page['pathnodes']);
array_pop($page['pathnodes']);

// ACTION: browse
// PARAMETERS: PROJECT
// COMMANDS: ls -v (1), info (1), log (N)
if ($do == 'browse' && isset($project)) {
	if (!isset($path)) { $path = '/'; }
	$page['title'] = "$project:$path - ViewSVN";
	$page['nodes'] = $svn->listFiles(isset($rev) ? $rev : 'HEAD');
	
	if ($config['enable_proplist']) {
		$page['proplist'] = $svn->getProperties($rev);
		if (!strlen($page['proplist'])) {
			unset($page['proplist']);
		}
	}
	
	require('templates/browse.php');
}

// A: diff
// P: PROJECT, PATH, REV, OLDREV, RAW?
// C: diff
elseif ($do == 'diff' && isset($project) && isset($path) && isset($rev) && isset($oldrev)) {
	if (!$config['enable_diff']) { die('Diff has not been enabled'); }

	if (isset($_REQUEST['raw'])) {
		header("Content-type: text/plain");
		die($svn->getDiff($oldrev, $rev));
	}
	
	// Colorify added/removed/@@ lines, and link "Index:" lines
	$page['content'] = preg_replace(array(
		'/^(@@.*@@)$/m',
		'/^(-.*)$/m',
		'/^(\+.*)$/m',
		'/^Index: (.+)$/m',
		), array(
		'<span class="pos">$1</span>',
		'<span class="removed">$1</span>',
		'<span class="added">$1</span>',
		"Index: <a href=\"?do=view&amp;project=$project&amp;path=$path$1&amp;rev=$rev\" title=\"View this file\">$1</a>",
		), 
		htmlspecialchars($svn->getDiff($oldrev, $rev)));
	$page['oldrev'] = $oldrev;
	$page['title'] = "Diff $oldrev-$rev - $project:$path - ViewSVN";

	require('templates/diff.php');
}

// A: download
// P: PROJECT, PATH, REV?
// C: cat
elseif ($do == 'download' && isset($project) && isset($path) && isset($rev)) {
	if (!$config['enable_download']) { die('Download has not been enabled'); }

	header('Content-type: archive/x-tar');
	header("Content-disposition: filename=$project-snapshot.tar.bz2");

	echo $svn->downloadArchive($rev);
}

// A: list
// P: PROJECT, PATH, REV?
// C: ls -R
elseif ($do == 'list' && isset($project) && isset($path)) {
	if (!$config['enable_list']) { die('List has not been enabled'); }

	$page['nodes'] = $svn->getListVerbose($rev);
	require('templates/list.php');
}

// A: log
// P: PROJECT, PATH, REV?
// C: log
elseif ($do == 'log' && isset($project) && isset($path)) {
	if (!$config['enable_log']) { die('Log viewing has not been enabled'); }

	$page['title'] = 'View log';
	$page['entries'] = $svn->getLog($rev, 1, $config['log_limit']);
	require('templates/log.php');
}

// A: rss
// P: PROJECT, PATH
// C: log
elseif ($do == 'rss' && isset($project) && isset($path)) {
	if (!$config['enable_rss']) { die('RSS feeds have not been enabled'); }

	$page['items'] = $svn->getLog('HEAD', '1', $config['rss_limit']);
	require('templates/rss.php');
}

// A: view
// P: PROJECT, PATH, REV?, ANNOTATE?, RAW?
// C: cat
elseif ($do == 'view' && isset($project) && isset($path)) {
	$page['title'] = "$project:$path ($rev) - ViewSVN";

	if (isset($_REQUEST['raw'])) {
		header('Content-type: text/plain');
		echo $svn->getFileContents($rev);
		die();
	}

	if (isset($_REQUEST['annotate']) && $config['enable_annotate']) {
		$content = htmlspecialchars($svn->getAnnotation($rev));
		$content = preg_replace('/^( *)(\d+)/m', "\\1<a href=\"?do=view&amp;project=$project&amp;path=$path&amp;rev=\\2\">\\2</a> <a href=\"?do=log&amp;project=$project&amp;path=$path&amp;rev=\\2\" title=\"View log entry for this line\">?</a>", $content);
		$page['filecontent'] = $content;
	}
	else {
		// Get file extension from current path
		$tmp = explode('.', $path);
		$ext = array_pop($tmp);
		if ($ext == 'cc' || $ext == 'hh') { $ext = 'cpp'; }

		if ($config['enable_geshi'] && strlen($ext) > 0) {
			include_once($config['geshi_path']);
			$geshi =& new GeSHi($svn->getFileContents($rev), GeSHi::get_language_name_from_extension($ext));
			$page['filecontent'] = $geshi->parse_code();
		} else {
			$page['filecontent'] = htmlspecialchars($svn->getFileContents($rev));
		}
	}
	require('templates/view.php');
}

// A: index
// P: -
// C: -
else {
	// if there is only one project, browse it by default
	if (count(array_keys($config['projects'])) == 1) {
		$target = array_keys($config['projects']);
		$target = array_shift($target);
		header("Location: http://". $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'] . "?do=browse&project=$target");
		die();
	}

	$page['title'] = 'ViewSVN - List of projects';
	$page['description'] = 'List of projects available for browsing';
	$page['projects'] = array();
	foreach ($config['projects'] as $p => $v) {
		array_push($page['projects'], array(
			'name' => $p,
			'description' => $v['description'],
			'path' => isset($v['startpath']) ? $v['startpath'] : '/',
		));
	}
	require('templates/projectlist.php');
}
?>

<?php
require('path.php');

echo "<h1>Differences for ". htmlentities($page['path']) ." between r$page[oldrev] and r$page[rev]</h1>\n";

echo "<div class=\"file\"><pre>";
echo $page['content'];
echo "</pre></div>";

echo "<div class=\"nav\">";
echo "<a href=\"". makelink(array('do' => 'diff', 'project' => $page['project'], 'path' => $page['path'], 'rev' => $page['rev'], 'oldrev' => $page['oldrev'], 'raw' => '1')) ."\">Download raw diff</a>";
echo "</div>\n";

?>

<?
require('include/common.php');

if (isfile($path)) {
	$viewfile = true;
}

if (isset($viewfile) && isset($download)) {
	header("Content-type: application/octet-stream");
	header("Content-disposition: attachment, filename=". basename($path));
	echo runsvn("cat -r$rev ". getshpath());
	die();
}
?>
<? require('include/header.php'); ?>

<? if (count($projects) > 1 && !strcmp($path, '/')) { ?>
<div class="project">
Project: 
<form action="viewsvn.php" method="get">
<fieldset>
<select name="project" onChange="submit()"><?
foreach ($projects as $tmp) {
	echo "<option";
	if (!strcmp($tmp, $project)) {
		echo " selected=\"selected\"";
	}
	echo ">$tmp</option>\n";
}
?></select>
<input type="submit" value="Go" />
</fieldset>
</form>
</div>
<? } ?>

<? require('include/path.php'); ?>

<?
if (!isset($viewfile) && !isset($diff)) {
	require('include/files.php');
} else {
?>
<div class="file">
<pre>
<?
if (isset($diff)) {
	echo colorifydiff(escapesnippet(runsvn("diff -r$diff:$rev ". getshpath())));
}
else if (isset($annotate)) {
	echo escapesnippet(runsvn("annotate -r$rev ". getshpath()));
} else {
	echo escapesnippet(runsvn("cat -r$rev ". getshpath()));
}
?>
</pre>
</div>
<?
}
?>

<div class="nav">
<?
if (isset($viewfile)) {
	if (!isset($annotate)) {
		echo "<a href=\"?project=$project&amp;path=$path&amp;annotate=yes\">Annotate</a>\n";
	}
	echo "<a href=\"?project=$project&amp;path=$path&amp;download=yes\">Download</a>\n";
}
?>
<a href="log.php?<? echo "project=$project&amp;path=$path"; ?>">View log</a>
</div>

<?
require('include/changeview.php');
?>

<? require('include/ad.php'); ?>

</body>
</html>


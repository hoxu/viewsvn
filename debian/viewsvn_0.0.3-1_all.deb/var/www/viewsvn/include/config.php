<?
// Set these if the repositories are not readable by anonymous user
$svnusername = "hoxu";
$svnpassword = "hou";

// The root that contains the repositories
$svnroot = "svn://localhost/";

// List of projects in the root that will be accessible
$projects = array('asukibot', 'fealdia', 'gig', 'viewsvn');

// Default project
$project = $projects[0];

$svn = "/usr/bin/svn --non-interactive";
if (isset($svnusername)) {
	$svn .= " --username $svnusername";
}
if (isset($svnpassword)) {
	$svn .= " --password $svnpassword";
}

$path = "/";

require('config_check.php');
?>

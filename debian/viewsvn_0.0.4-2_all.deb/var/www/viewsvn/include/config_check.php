<?
require_once('functions.php');

$svnroot = rtrim($svnroot, '/');

?>

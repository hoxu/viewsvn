<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
<title>ViewSVN - <? echo $project ?> - <? echo getpath() ?></title>
<link rel="stylesheet" href="styles/default.css" type="text/css" />
<meta name="description" content="ViewSVN repository view of <? echo $project; ?>'s <? echo getpath() ?>" />
<meta name="keywords" content="viewsvn, repository, <? echo $project ?>" />
</head>
<body>

<?php
if ($config['proplist']) {
	$output = runsvn("proplist -v ". getshpath());
	if (strlen($output)) {
?>
<div class="file">
<pre>
<?php
echo $output;
?>
</pre>
</div>
<?php
	}
}
?>

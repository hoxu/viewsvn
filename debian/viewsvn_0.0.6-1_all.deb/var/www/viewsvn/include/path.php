<div class="path">
<?php
echo "[ <a href=\"viewsvn.php?project=$project&amp;path=/\">$project</a> ] ";

$components = getpathnodes($path);
$tmp = "/";
echo "/ ";
foreach ($components as $node) {
	 $tmp .= "$node/";
	 echo "<a href=\"viewsvn.php?project=$project&amp;path=$tmp\">$node</a>";
	 echo " / ";
}
?>
</div>

<?
// Show project changer only if there are multiple projects and the config specifies so
if (count($projects) > 1 && $config['project_changer'] && (!strcmp($path, '/') || $config['project_changer'] == 2)) {
	if ($config['project_index'] && $config['project_changer_type'] == 0) {
?>
<div class="project"><a href=".">List of projects</a></div>
<?
	}
	else {
	//else if (($config['project_changer'] == 2 || (!strcmp($path, '/') && $config['project_changer']))) {
?>
<div class="project">
Project: 
<form action="viewsvn.php" method="get">
<fieldset>
<select name="project" onChange="submit()"><?
	foreach ($projects as $tmp) {
		echo "<option";
		if (!strcmp($tmp, $project)) {
			echo " selected=\"selected\"";
		}
		echo ">$tmp</option>\n";
	}
?>
</select>
<input type="submit" value="Go" />
</fieldset>
</form>
</div>
<?
	}
}
?>


<? if (count($revs) > 1) { ?>
<div class="changeview">

<form action="viewsvn.php" method="get">
<fieldset>
<input type="hidden" name="project" value="<? echo $project; ?>" />
<input type="hidden" name="path" value="<? echo $path; ?>" />

<table>
<tr>
<td>Revision</td>
<td>
<select name="rev"><?
foreach ($revs as $tmp) {
	echo "<option";
	if ($tmp == $rev) {
		echo ' selected="selected"';
	}
	echo ">$tmp</option>\n";
}
?>
</select>
<? if ($rev < $revs[0]) { ?>
<a href="?<? echo "project=$project&amp;path=$path"; ?>">(newest)</a>
<? } ?>
</td>
</tr>
<? if (count($revs) > 1) { ?>
<tr>
<td>Diff with</td>
<td>
<select name="diff">
<option></option>
<?
foreach ($revs as $tmp) {
	if ($tmp == $rev) {
		continue;
	}
	echo "<option";
	if (isset($diff) && $tmp == $diff) {
		echo ' selected="selected"';
	}
	echo ">$tmp</option>\n";
}
?>
</select>
</td>
</tr>
<? } ?>
<tr>
<td colspan="2" style="text-align: center">
<input type="submit" value="Go" />
</td>
</tr>
</table>

</fieldset>
</form>

</div>
<? } ?>

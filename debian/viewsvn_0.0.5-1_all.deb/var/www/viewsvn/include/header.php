<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
<title>ViewSVN - <?php echo $project ?> - <?php echo getpath() ?></title>
<link rel="stylesheet" href="styles/default.css" type="text/css" />
<meta name="description" content="ViewSVN repository view of <?php echo $project; ?>'s <?php echo getpath() ?>" />
<meta name="keywords" content="viewsvn, repository, <?php echo $project ?>" />
</head>
<body>

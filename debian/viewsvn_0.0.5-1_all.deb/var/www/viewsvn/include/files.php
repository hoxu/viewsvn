<div class="files">
<table>
<tr class="header">
<td>File</td>
<td>Rev.</td>
<td><?php
if ($config['show_age']) {
	echo "Age";
} else {
	echo "Last change";
}
?></td>
<td>Author</td>
<td>Last log entry</td>
</tr>
<?php
$files = getfilesverbose($rev);
foreach ($files as $file) {
	if (!strlen($file->filename)) {
		break;
	 }
	if ($file->isdir) {
		echo "<tr class=\"dir";
	} else {
		echo "<tr class=\"file";
	}
	if ($file->rev == $rev) {
		echo " currev";
	}
	echo "\">\n";
	
	echo "<td class=\"name\">";
	if ($file->isdir) {
		echo "<a href=\"?project=$project&amp;path=$path$file->filename\">$file->filename</a>";
	} else {
		echo "<a href=\"?project=$project&amp;path=$path$file->filename\">$file->filename</a>";
	}
	echo "</td>\n";
	
	echo "<td class=\"rev\">$file->rev</td>\n";
	echo "<td class=\"age\">";
	if ($config['show_age']) {
		echo $file->age;
	} else {
		echo $file->date;
	}
	echo "</td>\n";
	echo "<td class=\"author\">$file->author</td>\n";
	echo "<td class=\"log\">". escapesnippet(substr($file->log, 0, 80)) ."</td>\n";
	echo "</tr>\n";
}
?>
</table>
</div>


<?php
function getfilesverbose($rev)
{
	$lines = explode("\n", runsvn("ls -v -r$rev ". getshpath()));

	$files = array();

	foreach ($lines as $line) {
		unset($tmp);
		$tmp->rev = (int)substr($line, 0, 7);
		$tmp->author = trim(substr($line, 8, 8));
		$tmp->size = trim(substr($line, 20, 8));
		$tmp->date = substr($line, 28, 12);
		$tmp->age = secstoage(time() - stamptotime($tmp->date));
		$tmp->filename = substr($line, 41);
		if (strstr($tmp->filename, "/")) {
		 	$tmp->isdir = true;
		} else {
			$tmp->isdir = false;
		}
		$tmp->log = getlastlogentry(getsvnpath(). $tmp->filename, $rev);
		array_push($files, $tmp);
	}
	return $files;
}

function getlastlogentry($node, $rev)
{
	$log = runsvn("log --xml -r$rev:1 ". escapeshellarg($node));
	if (preg_match("/<msg>([^<]*)/", $log, $matches) < 1) {
		return "(not found)";
	}
	return $matches[1];
}

// Return array of revisions where the node was modified
function getnoderevs($node)
{
	$log = runsvn("log --xml -q ". escapeshellarg($node));
	preg_match_all('/revision="(.+)">/', $log, $matches);
	return $matches[1]; // array
}

// Returns current FULL SVN path
function getsvnpath()
{
	global $svnroot, $project, $path;
	return $svnroot .'/'. $project . $path;
}

// Returns full path to the path/file, escaped for shell
function getshpath()
{
	return escapeshellarg(getsvnpath());
}

// Return relative path from the selected project's root
function getpath()
{
	global $path;
	return $path;
}

// Return elements of path
function getpathnodes($path)
{
	$nodes = array();
	foreach (explode('/', $path) as $node) {
		array_push($nodes, $node);
	}
	array_pop($nodes);
	array_shift($nodes);
	return $nodes;
}

function isfile($node)
{
	if (!strcmp(substr($node, -1), "/")) {
		return false;
	}
	return true;
}

// Jun 03 20:25
function stamptotime($stamp)
{
	$month = substr($stamp, 0, 3);
	$day = substr($stamp, 4, 2);
	$hour = substr($stamp, 7, 2);
	$min = substr($stamp, 10, 2);
	// Yes, this is a bug...
	return strtotime("$month $day ". date('Y') ." $hour:$min");
}

function secstoage($secs)
{
	$months = (int)($secs/(84600*30));
	if ($months > 1) {
		return "$months months";
	}
	$days = (int)($secs/84600);
	if ($days > 1) {
		return "$days days";
	}
	$hours = (int)($secs/3600);
	if ($hours > 1) {
		return "$hours hours";
	}
	$minutes = (int)($secs/60);
	if ($minutes > 1) {
		return "$minutes minutes";
	}
	return $secs . " seconds";
}

// Removes illegal components from path
function validatepath($path)
{
	foreach (explode('/', $path) as $node) {
		if (!strcmp($node, "..")) {
			return "/";
		}
	}
	return $path;
}

// Escapes chunk of text for showing in a webpage
function escapesnippet($text)
{
	return preg_replace(array(
		 '/&/',
		 '/</',
		 '/>/',
	), array(
		 '&amp;',
		 '&lt;',
		 '&gt;',
	), $text);
}

function colorifydiff($text)
{
	$patterns = array(
		'/^(@@.*@@)$/m',
		'/^(-.*)$/m',
		'/^(\+.*)$/m',
	);
	$replaces = array(
		'<span class="pos">$1</span>',
		'<span class="removed">$1</span>',
		'<span class="added">$1</span>',
	);
	return preg_replace($patterns, $replaces, $text);
}

// Wrapper function
function run($cmd, &$retval)
{
	exec($cmd, $output, $retval);
	return join("\n", $output);
}

function runsvn($cmd)
{
	global $svn;
	$output = run("$svn $cmd", $retval);
	/*
	if ($retval) {
		die("\"svn $cmd\" failed with output: ". join("\n", $output));
	}
	*/
	return $output;
}

function runsvnret($cmd, &$retval)
{
	global $svn;
	return run("$svn $cmd", $retval);
}

// Returns log entries in array
function svn_parsexmllog($log)
{
	$result = array();
	$numentries = preg_match_all("#<logentry\s+revision=\"(\d+)\">(.*)</logentry>#sU", $log, $entries);

	for ($i = 0; $i < $numentries; $i++) {
		$entrytags = $entries[2][$i];
		$entry['rev'] = $entries[1][$i];

		// Get author, date and msg
		preg_match("#<author>(.*)</author>#sU", $entrytags, $matches);
		$entry['author'] = $matches[1];
		preg_match("#<date>(.*)</date>#sU", $entrytags, $matches);
		$entry['fulldate'] = $matches[1];
		$entry['date'] = substr($entry['fulldate'], 0, 10);
		$entry['time'] = substr($entry['fulldate'], 11, 8);
		preg_match("#<msg>(.*)</msg>#sU", $entrytags, $matches);
		$entry['msg'] = $matches[1];

		$entry['paths'] = array();
		// Changed paths
		$numpaths = preg_match_all("#<path\s*(copyfrom-path=\"(.*)\"\s*)?(copyfrom-rev=\"(.*)\"\s*)?action=\"(.*)\"\s*>(.*)</path>#sU", $entrytags, $paths);
		for ($j = 0; $j < $numpaths; $j++) {
			$path = null;
			$path['action'] = $paths[5][$j];
			$path['path'] = $paths[6][$j];
			if (strlen($paths[2][$j])) {
				$path['copyfrom-path'] = $paths[2][$j];
			}
			if (strlen($paths[4][$j])) {
				$path['copyfrom-rev'] = $paths[4][$j];
			}
			array_push($entry['paths'], $path);
		}
		
		array_push($result, $entry);
	}

	return $result;
}

// Returns true if $path is a directory
function svn_isdir($svnpath, $rev)
{
	$retval = 0;
	$tmp = runsvnret("cat -r$rev ". escapeshellarg($svnpath), $retval);
	if ($retval) {
		return true;
	}
	return false;
}

?>

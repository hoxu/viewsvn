<?php
require('include/common.php');

if (isfile($path)) {
	$viewfile = true;
}

if (isset($viewfile) && isset($download)) {
	header("Content-type: application/octet-stream");
	header("Content-disposition: attachment, filename=". basename($path));
	echo runsvn("cat -r$rev ". getshpath());
	die();
}

require('include/header.php');
require('include/project.php');
require('include/path.php');

?>

<?php
if (!isset($viewfile) && !isset($diff)) {
	require('include/files.php');
} else {
?>
<div class="file">
<pre>
<?php
if (isset($diff)) {
	echo colorifydiff(escapesnippet(runsvn("diff -r$diff:$rev ". getshpath())));
}
else if (isset($annotate)) {
	echo escapesnippet(runsvn("annotate -r$rev ". getshpath()));
} else {
	echo escapesnippet(runsvn("cat -r$rev ". getshpath()));
}
?>
</pre>
</div>
<?
}
?>

<div class="nav">
<?php
if (isset($viewfile)) {
	if (!isset($annotate)) {
		echo "<a href=\"?project=$project&amp;path=$path&amp;annotate=yes\">Annotate</a>\n";
	}
	echo "<a href=\"?project=$project&amp;path=$path&amp;download=yes\">Download</a>\n";
}
?>
<a href="log.php?<?php echo "project=$project&amp;path=$path"; ?>">View log</a>
</div>

<?php
require('include/changeview.php');
if (!isset($viewfile)) {
	require('include/proplist.php');
}
require('include/ad.php');
?>

</body>
</html>


<div class="files">
<table>
<tr class="header">
<td>File</td>
<td>Rev.</td>
<td><?php
if ($config['show_age']) {
	echo "Age";
} else {
	echo "Last change";
}
?></td>
<td>Author</td>
<td>Last log entry</td>
</tr>
<?php
foreach ($filelist as $file) {
	if (!strlen($file->filename)) {
		break;
	 }
	if ($file->isdir) {
		echo "<tr class=\"dir";
	} else {
		echo "<tr class=\"file";
	}
	if ($file->rev == $rev) {
		echo " currev";
	}
	echo "\">\n";
	
	echo "<td class=\"name\">";
	echo "<a href=\"?";
	echo http_build_query(array_merge($_GET, array('project' => $project, 'path' => "$path$file->filename")));
	echo "\">$file->filename</a>";
	echo "</td>\n";
	
	echo "<td class=\"rev\"><a href=\"?";
	echo http_build_query(array_merge($_GET, array('project' => $project, 'path' => $path, 'rev' => $file->rev)));
	//echo project=$project&amp;path=$path&amp;rev=$file->rev
	echo "\">$file->rev</a></td>\n";
	echo "<td class=\"age\">";
	if ($config['show_age']) {
		echo secstoage(time() - $file->age);
	} else {
		echo $file->date;
	}
	echo "</td>\n";
	echo "<td class=\"author\">$file->author</td>\n";
	echo "<td class=\"log\"><a href=\"log.php?project=$project&amp;path=$path$file->filename#r$file->rev\" title=\"View full log entry\">&raquo;</a>". substr($file->log, 0, 80) ."</td>\n";
	echo "</tr>\n";
}
?>
</table>
</div>


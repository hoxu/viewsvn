<?php

$svnroot = rtrim($svnroot, '/');

// Migration 0.0.7->
if (isset($svn)) {
	die('include/config.php: Use of the "svn" setting is deprecated, please set $config[\'svncommand\'] instead.');
}

if (isset($config['projects'])) {
	$projects = array_keys($config['projects']);
}
?>

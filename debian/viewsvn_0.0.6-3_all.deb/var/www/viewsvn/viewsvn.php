<?php
require('include/common.php');

if ($svn->pathIsFile()) {
	$viewfile = true;
}

if (isset($viewfile) && isset($download)) {
	header("Content-type: application/octet-stream");
	header("Content-disposition: attachment, filename=". basename($path));
	echo $svn->getFileContents($rev);
	die();
}

require('include/header.php');
require('include/project.php');
require('include/path.php');

if (!isset($viewfile) && !isset($diff)) {
	$filelist = $svn->listFiles($rev);
	require('include/files.php');
} else {
?>
<div class="file">
<pre>
<?php
if (isset($diff)) {
	echo colorifydiff(escapesnippet($svn->getDiff($diff, $rev)));
}
else if (isset($annotate)) {
	echo linkifyAnnotation($project, $svn->getPath(), escapesnippet($svn->getAnnotation($rev)));
} else {
	echo escapesnippet($svn->getFileContents($rev));
}
?>
</pre>
</div>
<?php
}
?>

<div class="nav">
<?php
if (isset($viewfile)) {
	if (!isset($annotate)) {
		echo "<a href=\"?project=$project&amp;path=$path&amp;annotate=yes\">Annotate</a>\n";
	}
	echo "<a href=\"?project=$project&amp;path=$path&amp;download=yes\">Download</a>\n";
}
?>
<a href="log.php?<?php echo "project=$project&amp;path=$path"; ?>">View log</a>
<?php
if ($config['rss']) {
?>
<a href="rss.php?<?php echo "project=$project&amp;path=$path"; ?>">RSS</a>
<?php
}
?>
</div>

<?php
require('include/changeview.php');
if (!isset($viewfile)) {
	require('include/proplist.php');
}
require('include/footer.php');
?>

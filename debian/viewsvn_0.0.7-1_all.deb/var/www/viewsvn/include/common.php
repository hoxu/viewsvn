<?php
error_reporting(E_ALL);
require_once('defaults.php');
require_once('config.php');
require_once('config_check.php');
require_once('functions.php');
require_once('libsvn.php');

$path = "/";
// Make sure the path is valid
if (isset($_GET['path'])) {
	$path = $_GET['path'];
	 //$path = validatepath($_GET['path']);
}

if (isset($_GET['project'])) {
	// check that it is in $projects array
	if (in_array($_GET['project'], $projects)) {
		$project = $_GET['project'];
	} else {
		// Baruch, will this make you happier? :-)
		die("Project '$_GET[project]' does not exist!");
	}
} else {
	if (!isset($project)) {
		$project = $projects[0];
	}
}

$svn = new SVN();
if (isset($svnusername) && isset($svnpassword)) {
	$svn->setAuthentication($svnusername, $svnpassword);
}
if (isset($config['svncommand'])) {
	$svn->setCommand($config['svncommand']);
}
if (isset($config['projects'][$project]['username']) && isset($config['projects'][$project]['password'])) {
	$svn->setAuthentication($config['projects'][$project]['username'], $config['projects'][$project]['password']);
}
if (isset($config['projects'][$project]['root'])) {
	$svn->setRoot($config['projects'][$project]['root']);
} else {
	$svn->setRoot($svnroot . '/'. $project);
}
$svn->setPath($path);
$path = $svn->getPath();
if (isset($config['cachedir'])) { $svn->setCacheDir($config['cachedir']); }

// Get revisions for a path/file
$revs = $svn->getRevisions();

// Set current revision to be the newest one by default
if (!count($revs)) {
	die("No revisions found for $path. Please make sure ". $svn->getFullPath() . " is a valid svn repository (and username/password are correct).");
}
$rev = $revs[0];

// Make sure user-specified rev is valid
if (isset($_GET['rev'])) {
	if (in_array($_GET['rev'], $revs)) {
		$rev = $_GET['rev'];
	}
}

unset($diff);
if (isset($_GET['diff'])) {
	if (!strcmp($_GET['diff'], "prev")) {
		$index = intval(array_search($rev, $revs)) + 1;
		if ($index < count($revs)) {
			$diff = $revs[$index];
		}
	}
	else if (in_array($_GET['diff'], $revs) && ($_GET['diff'] != $rev)) {
		$diff = $_GET['diff'];
	}
}

if (isset($_GET['download'])) {
	$download = true;
}

if (isset($_GET['annotate'])) {
	$annotate = true;
}

header("Content-Type: text/html; charset=UTF-8");
?>

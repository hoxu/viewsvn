<?php
require_once('libsvn.php');

function colorifydiff($text)
{
	$patterns = array(
		'/^(@@.*@@)$/m',
		'/^(-.*)$/m',
		'/^(\+.*)$/m',
	);
	$replaces = array(
		'<span class="pos">$1</span>',
		'<span class="removed">$1</span>',
		'<span class="added">$1</span>',
	);
	return preg_replace($patterns, $replaces, $text);
}

/// Escapes chunk of text for showing in a webpage
function escapesnippet($text)
{
	return preg_replace(array(
		 '/&/',
		 '/</',
		 '/>/',
	), array(
		 '&amp;',
		 '&lt;',
		 '&gt;',
	), $text);
}

// Return elements of path
function getpathnodes($path)
{
	$nodes = array();
	foreach (explode('/', $path) as $node) {
		array_push($nodes, $node);
	}
	array_pop($nodes);
	array_shift($nodes);
	return $nodes;
}

// Returns public url to the viewsvn directory
function getviewsvnurl()
{
	return "http://". $_SERVER['SERVER_NAME'] . dirname($_SERVER['SCRIPT_NAME']);
}

// Poor man's replacement for PHP5's http_build_query
if (!function_exists('http_build_query')) {
function http_build_query($arr)
{
	$pairs = array();
	foreach ($arr as $key => $value) {
		$pairs[] = urlencode($key).'='.urlencode($value);
	}
	$result = join('&amp;', $pairs);

	// Don't escape slashes
	$result = str_replace('%2F', '/', $result);
	return $result;
}
}

function isfile($node)
{
	if (!strcmp(substr($node, -1), "/")) {
		return false;
	}
	return true;
}

/**
 * Links revision numbers in output of "svn annotate"
 */
function linkifyAnnotation($project, $path, $data)
{
	return preg_replace('/^( *)(\d+)/m', "\\1<a href=\"viewsvn.php?project=$project&amp;path=$path&amp;rev=\\2\">\\2</a>", $data);
}

function secstoage($secs)
{
	$months = (int)($secs/(84600*30));
	if ($months > 1) {
		return "$months months";
	}
	$days = (int)($secs/84600);
	if ($days > 1) {
		return "$days days";
	}
	$hours = (int)($secs/3600);
	if ($hours > 1) {
		return "$hours hours";
	}
	$minutes = (int)($secs/60);
	if ($minutes > 1) {
		return "$minutes minutes";
	}
	return $secs . " seconds";
}

// Removes illegal components from path
function validatepath($path)
{
	foreach (explode('/', $path) as $node) {
		if (!strcmp($node, "..")) {
			return "/";
		}
	}
	return $path;
}

?>

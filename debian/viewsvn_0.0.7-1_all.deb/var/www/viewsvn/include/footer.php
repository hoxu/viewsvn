<?php
require('include/ad.php');

echo "<!-- DEBUG:\n";
if (isset($svn)) {
	echo $svn->debugInfo();
}
echo "\n-->";
?>

</body>
</html>

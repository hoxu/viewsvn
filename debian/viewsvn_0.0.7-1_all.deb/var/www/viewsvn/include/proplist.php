<?php
if ($config['proplist']) {
	$output = $svn->getProperties($rev);
	if (strlen($output)) {
?>
<div class="file">
<pre>
<?php
echo $output;
?>
</pre>
</div>
<?php
	}
}
?>

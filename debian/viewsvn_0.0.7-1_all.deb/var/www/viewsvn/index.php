<?php
require('include/defaults.php');
require('include/config.php');
require('include/config_check.php');

if ((count($projects) <= 1) || !$config['project_index']) {
	header("Location: viewsvn.php?project=$project");
	die();
}

?>
<html>
<head>
<title>ViewSVN - List of projects</title>
<link rel="stylesheet" href="styles/default.css" type="text/css" />
</head>
<body>

<h1>List of projects available for viewing</h1>

<div id="projectlist">
<ul>
<?php
foreach ($projects as $tmp) {
	echo "<li><a href=\"viewsvn.php?project=$tmp\">$tmp";
	if (isset($config['projects'][$tmp]['description'])) {
		echo " &sim; ". $config['projects'][$tmp]['description'];
	}
	echo "</a></li>\n";
}
?>
</ul>
</div>

<?php require('include/footer.php'); ?>

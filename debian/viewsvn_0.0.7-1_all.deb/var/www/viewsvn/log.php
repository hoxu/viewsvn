<?php
require('include/common.php');

if (isset($_GET['xml'])) {
	header("Content-type: text/xml");
	echo $svn->getLogXML();
	die();
}

require('include/header.php');
require('include/project.php');
require('include/path.php');
?>

<div class="log">
<?php

$entries = $svn->getLog();

$logpath = $path;
$num = 0;
foreach ($entries as $entry) {
	$num++;
	echo "<div class=\"entry\">\n";
	echo "<div class=\"info\">\n";
	echo "<a name=\"r$entry[rev]\"></a>";
	echo "<span class=\"rev\"><a href=\"viewsvn.php?project=$project&amp;path=$logpath&amp;rev=$entry[rev]\">r$entry[rev]</a></span> | ";
	echo "<span class=\"author\">$entry[author]</span> | ";
	echo "<span class=\"date\">$entry[date] $entry[time]</span>";
	if ($num < count($entries)) {
		echo " | <span class=\"\diff\"><a href=\"viewsvn.php?project=$project&amp;path=$logpath&amp;rev=$entry[rev]&amp;diff=prev\">View changes</a></span>";
	}
	echo "</div>\n";

	echo "<div class=\"paths\">";
	echo "<ul>";
	foreach ($entry['paths'] as $path) {
		echo "<li>";
		if ($path['action'] == 'M') {
			echo "<a href=\"viewsvn.php?project=$project&amp;path=$path[path]&amp;rev=$entry[rev]&amp;diff=prev\" title=\"View changes\">";
		}
		echo "$path[action]";
		if ($path['action'] == 'M') {
			echo "</a>";
		}
		echo " ";
		if ($path['action'] != 'D') {
			echo "<a href=\"viewsvn.php?project=$project&amp;path=$path[path]&amp;rev=$entry[rev]\">";
		}
		echo $path['path'];
		if ($path['action'] != 'D') {
			echo "</a>";
		}
		if (isset($path['copyfrom-path'])) {
			$frompath = $path['copyfrom-path'];
			$fromrev = $path['copyfrom-rev'];
			echo " (from <a href=\"viewsvn.php?project=$project&amp;path=$frompath&amp;rev=$fromrev\">". $frompath .":". $fromrev ."</a>)";
		}

		echo "</li>\n";
	}
	echo "</ul>";
	echo "</div>";

	echo "<div class=\"msg\"><pre>". $entry['msg'] ."</pre></div>";

	echo "</div>\n";
}

?>
</div>

<?php
require('include/footer.php');
?>

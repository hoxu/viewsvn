<?php
require('include/common.php');

if (!$config['download']) { die('Downloads not enabled'); }

header('Content-type: archive/x-tar');
header('Content-disposition: filename=snapshot.tar.bz2');
echo $svn->downloadArchive($rev);
?>
